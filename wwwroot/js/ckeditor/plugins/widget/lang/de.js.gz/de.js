/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */
CKEDITOR.plugins.setLang( 'widget', 'de', {
	'move': 'Zum Verschieben anwählen und ziehen',
	'label': '%1 Steuerelement'
} );
