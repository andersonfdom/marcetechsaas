/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */

CKEDITOR.plugins.setLang( 'devtools', 'uk', {
	title: 'Відомості про Елемент',
	dialogName: 'Заголовок діалогового вікна',
	tabName: 'Назва вкладки',
	elementId: 'Ідентифікатор Елемента',
	elementType: 'Тип Елемента'
} );
