/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'docprops', 'mk', {
	bgColor: 'Background Color',
	bgFixed: 'Non-scrolling (Fixed) Background', // MISSING
	bgImage: 'Background Image URL', // MISSING
	charset: 'Character Set Encoding', // MISSING
	charsetASCII: 'ASCII', // MISSING
	charsetCE: 'Central European', // MISSING
	charsetCR: 'Cyrillic', // MISSING
	charsetCT: 'Chinese Traditional (Big5)', // MISSING
	charsetGR: 'Greek', // MISSING
	charsetJP: 'Japanese', // MISSING
	charsetKR: 'Korean', // MISSING
	charsetOther: 'Other Character Set Encoding', // MISSING
	charsetTR: 'Turkish', // MISSING
	charsetUN: 'Unicode (UTF-8)', // MISSING
	charsetWE: 'Western European', // MISSING
	chooseColor: 'Choose',
	design: 'Design', // MISSING
	docTitle: 'Page Title', // MISSING
	docType: 'Document Type Heading', // MISSING
	docTypeOther: 'Other Document Type Heading', // MISSING
	label: 'Document Properties', // MISSING
	margin: 'Page Margins', // MISSING
	marginBottom: 'Доле',
	marginLeft: 'Лево',
	marginRight: 'Десно',
	marginTop: 'Горе',
	meta: 'Meta Tags', // MISSING
	metaAuthor: 'Author', // MISSING
	metaCopyright: 'Copyright', // MISSING
	metaDescription: 'Document Description', // MISSING
	metaKeywords: 'Document Indexing Keywords (comma separated)', // MISSING
	other: 'Other...', // MISSING
	previewHtml: '<p>This is some <strong>sample text</strong>. You are using <a href="javascript:void(0)">CKEditor</a>.</p>', // MISSING
	title: 'Document Properties', // MISSING
	txtColor: 'Text Color', // MISSING
	xhtmlDec: 'Include XHTML Declarations' // MISSING
} );
