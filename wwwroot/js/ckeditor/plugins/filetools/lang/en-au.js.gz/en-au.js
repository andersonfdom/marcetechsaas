/**
 * @license Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
 * CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
 */
CKEDITOR.plugins.setLang( 'filetools', 'en-au', {
	loadError: 'Error occurred during file read.',
	networkError: 'Network error occurred during file upload.',
	httpError404: 'HTTP error occurred during file upload (404: File not found).',
	httpError403: 'HTTP error occurred during file upload (403: Forbidden).',
	httpError: 'HTTP error occurred during file upload (error status: %1).',
	noUrlError: 'Upload URL is not defined.',
	responseError: 'Incorrect server response.'
} );
